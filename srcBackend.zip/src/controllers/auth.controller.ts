import { Controller, Post, Body, UseGuards, Request } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from '../services/auth.service';
import { LoginDto } from '../dto/login.dto';
import { CreateUserDto } from '../dto/create-user.dto';
import { RolesGuard, RequireRoles } from '../config/roles.guard';
import { Roles } from 'src/enums/Roles';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  // POST /auth/login  — ouvert à tous
  @Post('login')
  login(@Body() dto: LoginDto) {
    return this.authService.login(dto);
  }

  // POST /auth/users  — réservé à l'admin
  @Post('users')
  @UseGuards(AuthGuard('jwt'), RolesGuard)
  @RequireRoles(Roles.ADMIN)
  createUser(@Body() dto: CreateUserDto) {
    return this.authService.createUser(dto);
  }
}
export class CreateAgendaDto {}

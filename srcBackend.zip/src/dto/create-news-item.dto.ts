export class CreateNewsItemDto {}

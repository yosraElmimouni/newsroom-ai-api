export class CreateIaAnalyseDto {}

export class CreateMediaDto {}
